
<?php $__env->startSection('contents'); ?>
<?php $__env->startSection('meta'); ?>
<title><?php echo e($page->title); ?></title>
<meta name="Description" content="<?php echo $page->description; ?>">
<meta property="og:title" content="<?php echo e($page->title); ?>" />
<meta property="og:description" content="<?php echo $page->description; ?>" />
<meta property="og:image" content="<?php echo e(asset('assets/images/'.$gs->og_baner)); ?>" />
<?php $__env->stopSection(); ?>
             
                         
 <div class="create-page">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="create-pageTitle">                        
                            <span> <?php echo e($page->title); ?> </span>     
                        </div>
                        
                        <div class="create-page-details">
                        <p> <?php echo $page->description; ?> </p>
						</div>
                        
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/creativedesignbd/news2.creativedesign.com.bd/project/resources/views/frontend/page.blade.php ENDPATH**/ ?>