             
            <!--======= Footer Section Start============-->
            <div class="footer-section">
                <div class="row">
                        <div class="col-md-2 col-sm-2 col-xs-4">
                           <div class="footer-menu-01">
                               <div class="menu"><ul>
<li class="page_item page-item-1147"><a href="<?php echo e(URL::to('/reporter')); ?>"><?php echo e(__('Our Reporters')); ?></a></li>
<li class="page_item page-item-1208"><a href="<?php echo e(URL::to('/photo')); ?>"><?php echo e(__('Photo Gallery')); ?></a></li>
<li class="page_item page-item-1211"><a href="<?php echo e(URL::to('/video')); ?>"><?php echo e(__('Video Gallery')); ?></a></li>
</ul></div>
                           </div>
                        </div>

                        <div class="col-md-2 col-sm-2 col-xs-4">
                           <div class="footer-menu-01">
                               <div class="menu"><ul>
<li class="page_item page-item-1147"><a href="<?php echo e(URL::to('/reporter')); ?>"><?php echo e(__('Our Reporters')); ?></a></li>
<li class="page_item page-item-1208"><a href="<?php echo e(URL::to('/photo')); ?>"><?php echo e(__('Photo Gallery')); ?></a></li>
<li class="page_item page-item-1211"><a href="<?php echo e(URL::to('/video')); ?>"><?php echo e(__('Video Gallery')); ?></a></li>
</ul></div>
                           </div>
                        </div>

                        <div class="col-md-2 col-sm-2 col-xs-4">
                           <div class="footer-menu-01">
                                <div class="menu"><ul>
<li class="page_item page-item-1147"><a href="<?php echo e(URL::to('/reporter')); ?>"><?php echo e(__('Our Reporters')); ?></a></li>
<li class="page_item page-item-1208"><a href="<?php echo e(URL::to('/photo')); ?>"><?php echo e(__('Photo Gallery')); ?></a></li>
<li class="page_item page-item-1211"><a href="<?php echo e(URL::to('/video')); ?>"><?php echo e(__('Video Gallery')); ?></a></li>
</ul></div>
                           </div>
                        </div>

                        <div class="col-md-2 col-sm-2 col-xs-4">
                           <div class="footer-menu-01">
                               <div class="menu"><ul>
<li class="page_item page-item-1147"><a href="<?php echo e(URL::to('/reporter')); ?>"><?php echo e(__('Our Reporters')); ?></a></li>
<li class="page_item page-item-1208"><a href="<?php echo e(URL::to('/photo')); ?>"><?php echo e(__('Photo Gallery')); ?></a></li>
<li class="page_item page-item-1211"><a href="<?php echo e(URL::to('/video')); ?>"><?php echo e(__('Video Gallery')); ?></a></li>
</ul></div>
                           </div>
                        </div>

                        <div class="col-md-2 col-sm-2 col-xs-4">
                           <div class="footer-menu-01">
						   
						   					<?php
    // বর্তমান ল্যাঙ্গুয়েজ আইডি বের করছি
    $lid = Session::has('language') 
        ? Session::get('language') 
        : DB::table('languages')->where('is_default', 1)->first()->id;

    // Footer পেজগুলো নিচ্ছি বর্তমান ল্যাঙ্গুয়েজ অনুযায়ী
    $footer_menus = \App\Models\Page::where('placement', 'footer')
                    ->where('status', 1)
                    ->where('language_id', $lid)
                    ->get();
?>
						   
                               <div class="menu"><ul>
							   <?php $__currentLoopData = $footer_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class="page_item page-item-1147"><a href="<?php echo e(route('dynamic.page',$menu->slug)); ?>"><?php echo e($menu->title); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul></div>
                           </div>
                        </div>

                        <div class="col-md-2 col-sm-2 col-xs-4">
                           <div class="footer-menu-last">
                               <div class="menu"><ul>
							   
							   
		   <?php if(!auth()->user()): ?>						   
<li class="page_item page-item-1147"><a href="<?php echo e(route('front.LogReg')); ?>"><?php echo e(__('Login')); ?></a></li>
                                  <?php endif; ?>
									<?php if(auth()->user()): ?>
									     <?php
											 $data = auth()->user();
										 ?>
<li class="page_item page-item-1147"><a href="<?php echo e(route('user.dashboard')); ?>"><?php echo e(__('Reporter Dashboard')); ?></a></li>
<?php endif; ?>	



<li class="page_item page-item-1208"><a href="<?php echo e(URL::to('/photo')); ?>"><?php echo e(__('Photo Gallery')); ?></a></li>
<li class="page_item page-item-1211"><a href="<?php echo e(URL::to('/video')); ?>"><?php echo e(__('Video Gallery')); ?></a></li>
</ul></div>
                           </div>
                        </div>
                        
                    
                    </div>
                   
                <div class="footer-wrpp">
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <div class="footer-content-rihgt">
								 <?php echo e(__('Office')); ?> : <?php echo e(__('Office Address')); ?>, <?php echo e(__('Mob')); ?> : <?php echo e(__('Mobile Number')); ?> <?php echo e(__('Email')); ?>: <?php echo e($gs->email); ?>

                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="footer-content-left">
                                <?php echo e(__('Office')); ?> : <?php echo e(__('Office Address')); ?>, <?php echo e(__('Mob')); ?> : <?php echo e(__('Mobile Number')); ?> <?php echo e(__('Email')); ?>: <?php echo e($gs->email); ?>

                            </div>
                        </div>
                    </div>
                    
                
                    
                    
                    
                </div>
                
               
            
        
						
			
	

 <div class="root">
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <div class="root_01">
                            <?php echo e(__('Footer Credite')); ?> </div>

                        </div>
                       <div class="col-md-6 col-sm-6">
                           <div class="root_02">
                                সকল কারিগরী সহযোগিতায় <a href='http://www.creativedesign.com.bd/' target='_blank' title='creativedesign.com.bd
'>ক্রিয়েটিভ ডিজাইন</a> 
                            </div>
                       </div>
                    </div>
                
                </div>
                <a href="#" class="scrollToTop"><i class="fa fa-angle-up"></i></a>
            </div>
            
            
            <!--======= Footer Section End============-->
            
            
               
            </div>
  </section> 		<?php /**PATH /home/creativedesignbd/news2.creativedesign.com.bd/project/resources/views/partial/front/footer.blade.php ENDPATH**/ ?>