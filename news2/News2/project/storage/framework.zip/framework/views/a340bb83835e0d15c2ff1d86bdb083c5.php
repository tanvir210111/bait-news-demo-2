<?php $__env->startSection('contents'); ?>
    <?php $__env->startSection('meta'); ?>
<title><?php echo e($data->title); ?></title>
<meta property="og:title" content="<?php echo e($data->title); ?>" />
<meta property="og:image" content="<?php echo e(asset('assets/images/'.$gs->og_baner)); ?>" />
<?php $__env->stopSection(); ?>	
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>
         <!--==================================
               archive-page-section start
         ===================================-->

         <section class="archive-page-section">
		 
            
                    <div class="row">
                
                        <div class="col-md-8 col-sm-8">
										    <!--Next Pages Close--->

<div class="category_info">
<a href=""><i class="fa fa-home" aria-hidden="true"></i> 
							</a> <i class="fa fa-chevron-right"></i> <?php echo e($data->title); ?></div>

			   
		         <?php if($posts->count()>0): ?>                       
 <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>		   		   
		<div class="archive_page archive_back">
		    <div class="col-md-4 col-sm-4">
		        <!-- Post Image Code Start--> 
					<img width="480" height="250" src="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?> 480w, <?php echo e(asset('assets/images/post/'.$post->image_big)); ?> 300w" sizes="(max-width: 480px) 100vw, 480px" />					<!-- Post Image Code Close-->
					
		    </div>
		    <div class="col-md-8 col-sm-8">
		        <h3 class="archive_title01"><a href="<?php echo e(route('frontend.postBySubcategory.details',[$post->category->slug,$post->slug])); ?>"><?php echo e(strlen($post->title)>100 ? mb_substr($post->title,0,100,'utf-8').'...' : $post->title); ?> </a></h3>
							
                       <?php echo e(strlen($post->short_description)>250 ? mb_substr($post->short_description,0,250,'utf-8').'...' : $post->short_description); ?> <h4 class="archvie_more"><a href="<?php echo e(route('frontend.postBySubcategory.details',[$post->category->slug,$post->slug])); ?>"><?php echo e(__('Details')); ?>...</a></h4>
                       
		    </div>
		</div>
			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <?php else: ?>
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <p class="text-danger text-danger text-center"><?php echo e(__('This Category has no news.')); ?></p>
                                        </div>
                                    </div>
                                </div>
                        <?php endif; ?>  
	 		   		   
		
			    
	 	
	 

                    
                    

     <?php if($posts->hasPages()): ?>
    <div class="custom-pagination text-center mt-4 mb-4">
        <ul class="pagination-list">
            
            <?php if($posts->onFirstPage()): ?>
                <li class="disabled"><span>« <?php echo e(__('Previous')); ?></span></li>
            <?php else: ?>
                <li><a href="<?php echo e($posts->previousPageUrl()); ?>" rel="prev">« <?php echo e(__('Previous')); ?></a></li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $posts->links()->elements[0] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $posts->currentPage()): ?>
                    <li class="active"><span><?php echo e($page); ?></span></li>
                <?php else: ?>
                    <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($posts->hasMorePages()): ?>
                <li><a href="<?php echo e($posts->nextPageUrl()); ?>" rel="next"><?php echo e(__('Next')); ?> »</a></li>
            <?php else: ?>
                <li class="disabled"><span><?php echo e(__('Next')); ?> »</span></li>
            <?php endif; ?>
        </ul>
    </div>
<?php endif; ?>

						</div>
                        
                  <div class="col-md-4 col-sm-4">
                    <div class="tab-header">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs nav-justified" role="tablist">
								<li role="presentation" class="active"><a href="#tab21" aria-controls="tab21" role="tab" data-toggle="tab" aria-expanded="false"><?php echo e(__('Latest News')); ?></a></li>
								<li role="presentation" ><a href="#tab22" aria-controls="tab22" role="tab" data-toggle="tab" aria-expanded="true"> <?php echo e(__('Featured News')); ?> </a></li>
							</ul>

                            <!-- Tab panes -->
                            <div class="tab-content ">
                                <div role="tabpanel" class="tab-pane in active" id="tab21">

                                    <div class="news-titletab">
									
										<?php $__currentLoopData = $is_trendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_trending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                                        <div class="imagr-border">
											<div class="small-imgae">
												<a href="<?php echo e(route('frontend.postBySubcategory.details',[$is_trending->category->slug,$is_trending->slug])); ?>"> <img width="480" height="250" src="<?php echo e(asset('assets/images/post/'.$is_trending->image_big)); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="<?php echo e(asset('assets/images/post/'.$is_trending->image_big)); ?> 480w, <?php echo e(asset('assets/images/post/'.$is_trending->image_big)); ?> 300w" sizes="(max-width: 480px) 100vw, 480px" /> </a>
											</div>
											<div class="hadding_02">
											   <a href="<?php echo e(route('frontend.postBySubcategory.details',[$is_trending->category->slug,$is_trending->slug])); ?>"><?php echo e(strlen($is_trending->title)>60 ? mb_substr($is_trending->title,0,60,"utf-8") : $is_trending->title); ?></a>
											</div>
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
                                        
										
																				
                                    </div> 
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="tab22">                                      
                                    <div class="news-titletab">
                                       
									   											<?php $__currentLoopData = $is_recents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                                        <div class="imagr-border">
											<div class="small-imgae">
												<a href="<?php echo e(route('frontend.postBySubcategory.details',[$is_recent->category->slug,$is_recent->slug])); ?>"> <img width="480" height="250" src="<?php echo e(asset('assets/images/post/'.$is_recent->image_big)); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="<?php echo e(asset('assets/images/post/'.$is_recent->image_big)); ?> 480w, <?php echo e(asset('assets/images/post/'.$is_recent->image_big)); ?> 300w" sizes="(max-width: 480px) 100vw, 480px" /> </a>
											</div>
											<div class="hadding_02">
											   <a href="<?php echo e(route('frontend.postBySubcategory.details',[$is_recent->category->slug,$is_recent->slug])); ?>"><?php echo e(strlen($is_recent->title)>60 ? mb_substr($is_recent->title,0,60,"utf-8") : $is_recent->title); ?></a>
											</div>
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
										
										
										
										
                                    </div>                                          
                                </div>
                            </div>
                        </div>
					
					<div class="add">
						 <div class="widget_area">			<div class="textwidget"><?php echo $gs->sidebar_ads1; ?></div>
		</div>					</div>
							
                </div>
				
				
                </div>
   
         </section>

		
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/frontend/category.blade.php ENDPATH**/ ?>