

<script src="https://bangla.plus/scripts/bangladatetoday.min.js"></script>
<script>dateToday('date-today', 'bangla');</script>
           
<script>
                        setInterval(displayTime, 1000);

function displayTime() {

    const timeNow = new Date();

    let hoursOfDay = timeNow.getHours();
    let minutes = timeNow.getMinutes();
    let seconds = timeNow.getSeconds();
    let weekDay = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    let today = weekDay[timeNow.getDay()];
    let months = timeNow.toLocaleString("default", {
        month: "long"
    });
    let year = timeNow.getFullYear();
    let period = "AM";

    if (hoursOfDay > 12) {
        hoursOfDay-= 12;
        period = "PM";
    }

    if (hoursOfDay === 0) {
        hoursOfDay = 12;
        period = "AM";
    }

    hoursOfDay = hoursOfDay < 10 ? "0" + hoursOfDay : hoursOfDay;
    minutes = minutes < 10 ? "0" + minutes : minutes;
    seconds = seconds < 10 ? "0" + seconds : seconds;

    let time = hoursOfDay + ":" + minutes + ":" + seconds + " " + period;

   document.getElementById('Clock').innerHTML = time ;
    
    var chars = {'1':'১','2':'২','3':'৩','4':'৪','5':'৫','6':'৬','7':'৭','8':'৮','9':'৯','0':'০','A':'এ','P':'পি','M':'এম'};
    let str = document.getElementById("Clock").innerHTML; 
    let res = str.replace(/[1234567890AMP]/g, m => chars[m]);
    document.getElementById("Clock").innerHTML = res;

}
displayTime();

                        </script>
<section class="body-section">	
	<div class="container main_wbsite">
						
				            
            <!--=======header-section Start========-->
               <div class="header-section">
                    <div class="row">
                        <div class="col-md-4 col-sm-4 col-sm-4">
                            <div class="verson">
                                <a href="<?php echo e($gs->epaper_link); ?>"><i class="fa fa-newspaper-o" aria-hidden="true"></i>  <?php echo e(__('Epaper Version')); ?></a>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4 col-sm-4">
                            <div class="date">
                               						
							<?php echo e(__('Todays Date')); ?> :	<span id ="Clock" onload="displayTime()"></span> | <span id="date-today"></span> বঙ্গাব্দ												   
								                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <div class="top_hdr_social">
                                <ul>
								
								
								<?php $__currentLoopData = $social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social_link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
									<li><a href="<?php echo e($social_link->link); ?>" target="_blank" class="<?php echo e($social_link->name); ?>"> <i class="<?php echo e($social_link->icon); ?>"></i></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	


								</ul>
	                        </div>
                        </div>
                    </div>
               </div>
                
            <!--=======header-section End========-->
            
                
            
            
            <!--=======Logo & banner-section Start========-->
            
            <div class="logobanner-section">
                <div class="row">
							<?php
								Session::has('language') ? $lid=Session::get('language') : $lid = (DB::table('languages')->where('is_default','=',1)->first()->id)
							?>
							
							<?php
								$header_footer_logo = d_logo($lid);
							?>
                    <div class="col-md-4 col-sm-4">
                        <div class="logo">
                             <a href="<?php echo e(route('frontend.index')); ?>"><img src="<?php echo e(asset('assets/images/logo/'.$gs->logo)); ?>" alt="Logo" width="100%"></a>
                        </div>
                    </div>
                    <div class="col-md-8 col-sm-8">
                        <div class="banner">
                            <?php echo $gs->horizontal_adds1; ?>

                        </div>
                    </div>
                </div>
            </div>
            
        <!--=======Logo & banner-section End========-->
        
        
        <!--=======secroll-section start========-->
		
		
        <div class="row">
            <div class="col-md-9 col-sm-9">
                <div class="row">
                    <div class="col-md-12 top_scrool"> 
                        <div class="col-md-2 scrool_1">
							<?php echo e(__('News Headlines')); ?>						</div>
						<div class="col-md-10 scrool_2">
													
			<?php
    use App\Models\Post;
    use App\Models\Language;

    // ✅ বর্তমান ভাষা চেক
    if (session()->has('language')) {
        $default_language = Language::find(session('language'));
    } else {
        $default_language = Language::where('is_default', 1)->first();
    }

    // ✅ ভাষা অনুযায়ী ট্রেন্ডিং নিউজ কল
    $is_trendings = Post::where('is_trending', 1)
        ->where('is_pending', 0)
        ->where('schedule_post', 0)
        ->where('status', true)
        ->where('language_id', $default_language->id)
        ->orderBy('id', 'desc')
        ->take(15)
        ->get();
?>					<marquee direction = "left" scrollamount="4px" onmouseover="this.stop()" onmouseout="this.start()">
									
<?php if($is_trendings->count()>0): ?>
<?php $__currentLoopData = $is_trendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_trending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>		
									<i class="fa fa-square" aria-hidden="true"></i>
									<a href="<?php echo e(route('frontend.postBySubcategory.details',[$is_trending->category->slug,$is_trending->slug])); ?>"><?php echo e($is_trending->title); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
										<i class="fa fa-square" aria-hidden="true"></i>
									<a href=""><?php echo e(__('No Headlines News')); ?></a>
									<?php endif; ?>
																		
																		</marquee>
								
																							   						</div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-3">
                <div class="search-box">
                    <form class="example" method="get" action="<?php echo e(route('front.news_search')); ?>">
						<input type="text"  maxlength="64" placeholder="<?php echo e(__('Write Here')); ?>" value="" name="search" />
						<button type="submit"><?php echo e(__('Search')); ?></button>
					</form>
                </div>
            </div>
        </div>
		
		   
						
					
        <!--=======secroll-section End========-->
            
            
               
            <!-------menu option stsrt-------->


            <div class="row">
                <div class="col-xs-12 col-md-12 col-sm-12">
                    <div id="menu-area" class="menu_area">
                        <div class="menu_bottom">
                            <nav role="navigation" class="navbar navbar-default mainmenu">
                        <!-- Brand and toggle get grouped for better mobile display -->
                                <div class="navbar-header">
                                    <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>
                                <!-- Collection of nav links and other content for toggling -->
                                <div id="navbarCollapse" class="collapse navbar-collapse">
                                    <div class="menu-%e0%a6%aa%e0%a7%8d%e0%a6%b0%e0%a6%9a%e0%a7%8d%e0%a6%9b%e0%a6%a6-container"><ul id="menu-%e0%a6%aa%e0%a7%8d%e0%a6%b0%e0%a6%9a%e0%a7%8d%e0%a6%9b%e0%a6%a6" class="nav navbar-nav">
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <?php if($loop->first): ?>
        <li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement"
            id="menu-item-212"
            class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-212 active">
            <a title="<?php echo e($category->title); ?>" href="<?php echo e(route('frontend.index')); ?>">
                <i class="las la-home"></i> <?php echo e($category->title); ?>

            </a>
        </li>
    <?php endif; ?>

    
    <?php if($category->child()->count() > 0): ?>
        <li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement"
            id="menu-item-<?php echo e($category->id); ?>"
            class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-<?php echo e($category->id); ?> dropdown">

            
            <a title="<?php echo e($category->title); ?>" href="#" 
               data-href="<?php echo e(route('frontend.category', $category->slug)); ?>"
               data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true">
                <?php echo e($category->title); ?> <span class="caret"></span>
            </a>

            <ul role="menu" class="dropdown-menu">
                <?php $__currentLoopData = $category->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement"
                        id="menu-item-<?php echo e($child->id); ?>"
                        class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-<?php echo e($child->id); ?>">
                        <a title="<?php echo e($child->title); ?>"
                            href="<?php echo e(route('frontend.postBySubcategory.details', [$category->slug, $child->slug])); ?>">
                            <?php echo e($child->title); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>

    
    <?php else: ?>
        <?php if(! $loop->first): ?>
            <li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement"
                id="menu-item-<?php echo e($category->id); ?>"
                class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-<?php echo e($category->id); ?>">
                <a title="<?php echo e($category->title); ?>" href="<?php echo e(route('frontend.category', $category->slug)); ?>">
                    <?php echo e($category->title); ?>

                </a>
            </li>
        <?php endif; ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    // সাব ক্যাটাগরি থাকা মেনু আইটেমে ক্লিক করলে redirect করবে
    document.querySelectorAll('.menu-item-has-children > a.dropdown-toggle').forEach(function (link) {
        link.addEventListener('click', function (e) {
            // যদি ইউজার caret-এ ক্লিক করে, তাহলে শুধু dropdown খুলবে
            if (e.target.tagName === 'SPAN') return;

            // যদি মেইন লিংকে ক্লিক করে, তাহলে redirect করবে
            const href = this.getAttribute('data-href');
            if (href) {
                window.location.href = href;
            }
        });
    });
});
</script>

			

<li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" 
    id="menu-item-1167" 
    class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children dropdown">
    
    <a title="ভাষা" href="#" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true">
        ভাষা <span class="caret"></span>
    </a>

    <ul role="menu" class="dropdown-menu">

        <?php
            // সেশন থেকে ভাষা নেওয়া, না থাকলে ডিফল্ট ভাষা ব্যবহার
            $activeLang = Session::get('language') ?? DB::table('languages')->where('is_default', 1)->first()->id;
        ?>

        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li itemscope="itemscope" itemtype="https://www.schema.org/SiteNavigationElement" 
                id="menu-item-<?php echo e($language->id); ?>" 
                class="menu-item menu-item-type-taxonomy menu-item-object-category">
                
                <a title="<?php echo e($language->language); ?>" 
                   href="<?php echo e(route('front.language.change', $language->id)); ?>" 
                   class="<?php echo e($activeLang == $language->id ? 'active' : ''); ?>">
                    <?php echo e($language->language); ?>

                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </ul>
</li>





</ul></div>                                </div>
                            </nav>

                        </div><!-- /.header_bottom -->

                    </div>
                </div>

            </div>   
             <?php /**PATH C:\xampp\htdocs\project\resources\views/partial/front/header.blade.php ENDPATH**/ ?>