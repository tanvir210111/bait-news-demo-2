
<?php $__env->startSection('contents'); ?>
<?php $__env->startSection('meta'); ?>
<title><?php echo e($data->title); ?></title>
<meta name="Description" content="<?php echo $data->short_description; ?>">
<meta name="Keywords" content="<?php echo $data->meta_tag; ?>">
<meta property="og:title" content="<?php echo e($data->title); ?>" />
<meta property="og:description" content="<?php echo $data->short_description; ?>" />
<meta property="og:image" content="<?php echo e(asset('assets/images/post/'.$data->image_big)); ?>" />
<?php $__env->stopSection(); ?>

 <!--==================================
               national-section start
         ===================================-->

         <section class="singlepage-section">
		 
					
            <div class="row">
                <div class="col-md-8 col-sm-8">
				
					<div class="biggapon">
						 <div class="widget_area">			<div class="textwidget"><?php echo $gs->header1_728; ?></div>
		</div>					</div>
					
				
                    										
                    <div class="single-cat-info">
                        <div class="single-cat-home">
                            <a href=""><i class="fa fa-home" aria-hidden="true"></i> <?php echo e(__('Home')); ?> </a>
                        </div>
                        <div class="single-cat-cate">
                            <i class="fa fa-bars" aria-hidden="true"></i>  <a href="" rel="category tag"><?php echo e($data->category->title); ?> </a> 
                        </div>
                    </div>

                    <div class="single-title">
                        <h3><?php echo e($data->title); ?></h3>
                    </div>

					
					
				 <!--========= reporter image title section start ===========-->	
					

					<div class="view-section">
					 <div class="row">
                        <?php if($data->admin_id == 0 && $data->user_id != 0): ?>
                            <div class="col-md-1 col-sm-1 col-xs-2">
                                <div class="reportar-img">
								
																<img src="<?php echo e(asset('assets/images/admin/'.$data->user->photo)); ?>" width="100%" />
																
								
                                    
									
                                </div>
                            </div>
                            <div class="col-md-11 col-sm-11 col-xs-10">
                                <div class="reportar-sec">
                                    <div class="reportar-title">
										
										
																			
								<?php echo e(__('Reporter information')); ?> : <?php echo e($data->user->name); ?>								
																
								
								
                                    </div>
									<?php else: ?>
									                            <div class="col-md-1 col-sm-1 col-xs-2">
                                <div class="reportar-img">
								
																<img src="<?php echo e(asset('assets/images/admin/'.$data->admin->photo)); ?>" width="100%" />
																
								
                                    
									
                                </div>
                            </div>
                            <div class="col-md-11 col-sm-11 col-xs-10">
                                <div class="reportar-sec">
                                    <div class="reportar-title">
										
										
																			
								<?php echo e(__('Reporter information')); ?> : <?php echo e($data->admin->name); ?>								
																
								
								
                                    </div>
									 <?php endif; ?>
									
									
									
									
                                    <div class="sgl-page-views-count">
                                        <ul>
                                            <li> <i class="fa fa-clock-o"></i>  
											<?php echo e(__('News Release Date')); ?> : 
																						<?php echo e($data->createdAt()); ?>																																		</li>
											
											<!-- *(view-tab show or hide open)*-->	
												
												<!-- *(view-tab show or hide open)*-->
							
											<li class="active"> 
											<i class="fa fa-eye"></i> 

<?php echo e(__('How Many People See')); ?>: <?php echo e($data->views_count); ?>

											</li>
												
												 
										 									<!-- *(view-tab show or hide close)*-->
				
                                        </ul>
                                    </div>                                 
                                </div>
                            </div>
                        </div>
                    </div>
					
					
					<!--========= reporter image title section close ===========-->	
					
					

                    <div class="single-img">
                        <!-- Post Image Code Start--> 
						<img width="480" height="250" src="<?php echo e(asset('assets/images/post/'.$data->image_big)); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="<?php echo e(asset('assets/images/post/'.$data->image_big)); ?> 480w, <?php echo e(asset('assets/images/post/'.$data->image_big)); ?> 300w" sizes="(max-width: 480px) 100vw, 480px" />							<!-- Post Image Code Close-->
														<div class="caption">
								<?php echo e(__('Images Caption')); ?> : <?php echo e($data->images_caption); ?>

							</div>
						 
                    </div>

                    <div class="single-dtls">
					 <?php if($data->post_type == 'article'): ?>
                        <p><?php echo $data->description; ?></p>
			<a href="<?php echo e(URL::to('print/'.$data->id.'/'.$data->slug)); ?>" class="print-btn" style="margin-right: 10px;">
    <?php echo e(__('Print News')); ?>

</a>

<a href="<?php echo e(route('frontend.photo.card', [$data->id, $data->slug])); ?>" class="print-btn">
    <i class="fa fa-camera"></i> <?php echo e(__('Photo Card')); ?>

</a>


<style>
.print-btn {
  background: linear-gradient(135deg, #4CAF50, #2E7D32);
  color: #fff;
  border: none;
  padding: 10px 18px;
  font-size: 16px;
  font-weight: 600;
  border-radius: 8px;
  cursor: pointer;
  transition: 0.3s ease;
  box-shadow: 0 3px 6px rgba(0,0,0,0.2);
}

.print-btn:hover {
  background: linear-gradient(135deg, #43A047, #1B5E20);
  transform: translateY(-2px);
  box-shadow: 0 6px 10px rgba(0,0,0,0.25);
}

.print-btn:active {
  transform: translateY(0);
  box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}
</style>

					 <?php endif; ?>
					 
					 <?php if($data->post_type == 'video'): ?>
                          <?php if($data->embed_video): ?>	
					  <p><?php echo $data->description; ?></p>
				  	
					<iframe width="615" height="400" src="https://www.youtube.com/embed/<?php echo $data->embed_video; ?>" title="Types Of ভাড়াটিয়া || Comedy Special || Sanjay Das - Bishakto Sanju | Joy-Rupam-Ayan-Shuvro || 2024" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
								  <?php else: ?> 
									    <video controls >
                                            <source src="<?php echo e(asset('assets/videos/'.$data->video)); ?>" type="video/mp4">
                                        </video>
										<?php endif; ?>
								   
								   <?php endif; ?>
								   
				 								                              <?php if($data->post_type == 'audio'): ?>
	<p style="text-align: center;"><b><?php echo e(__('Audio File')); ?></b></p>
<audio controls="" style="width:100%">
				 <source src="<?php echo e(asset('assets/audios/'.$data->audio)); ?>" type="audio/mp3">
				</audio>
				 <?php echo $data->description; ?>

				<?php endif; ?>
					 
					 
					 
                    </div>
					
					<div class="add">
						 <div class="widget_area">			<div class="textwidget"><?php echo $gs->header2_728; ?></div>
		</div>					</div>
					
									                    <div class="sgl-cat-tittle">
                       <?php echo e(__('Comment Box')); ?>                   </div>
					   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v20.0&appId=1716117305495236" nonce="OKS9Fdbx"></script>
<div class="fb-comments" data-href="<?php echo e(URL::to($data->id.'/'.$data->slug)); ?>" data-width="600" data-numposts="10"></div>

										
                    <div class="sgl-page-social-title">
                        <h4><?php echo e(__('Share The News')); ?>..</h4>
                    </div>

                    <div class="sgl-page-social">
                        <ul>
							<li><a href="http://www.facebook.com/sharer.php?u=<?php echo e(URL::to($data->id.'/'.$data->slug)); ?>" class="ffacebook" target="_blank"> <i class="fa fa-facebook"></i> Facebook</a></li>

							<li><a href="https://twitter.com/share?text=<?php echo e(URL::to($data->id.'/'.$data->slug)); ?>" class="ttwitter" target="_blank"> <i class="fa fa-twitter"></i> Twitter</a></li>

							<li><a href="http://digg.com/submit?url=<?php echo e(URL::to($data->id.'/'.$data->slug)); ?>" class="digg" target="_blank"> <i class="fa fa-digg"></i> Digg </a></li>
							
							<li><a href="http://www.linkedin.com/shareArticle?mini=<?php echo e(URL::to($data->id.'/'.$data->slug)); ?>" class="linkedin" target="_blank"> <i class="fa fa-linkedin"></i> Linkedin </a></li>

							<li><a href="http://www.reddit.com/submit?url=<?php echo e(URL::to($data->id.'/'.$data->slug)); ?>" class="reddit" target="_blank"> <i class="fa fa-reddit"></i> Reddit </a></li>
							
							<li><a href="https://plus.google.com/share?url=<?php echo e(URL::to($data->id.'/'.$data->slug)); ?>" class="google-plus" target="_blank"> <i class="fa fa-google-plus"></i> Google Plus</a></li>

							<li><a href="http://www.pinterest.com/pin/create/button/?url=<?php echo e(URL::to($data->id.'/'.$data->slug)); ?>" class="pinterest" target="_blank"> <i class="fa fa-pinterest"></i> Pinterest </a></li>

							<li><a href="<?php echo e(URL::to('print/'.$data->id.'/'.$data->slug)); ?>" class="print" target="_blank"> <i class="fa fa-print"></i> Print </a></li>
						</ul>
						
                    </div>
					
					<script>
					function myFunction() {
						window.print();
					}
					</script>
					
					 
			 				   
				   <!-- *(view-tab show or hide open)*-->	
				


	 

						 
			 				<!-- *(view-tab show or hide close)*-->
				
					
									
                    <div class="sgl-cat-tittle">
                       <?php echo e(__('More news like this')); ?>..                    </div>
                    <div class="row">
			    <?php
				$popular=DB::table('posts')->inRandomOrder()->orderBy('id','DESC')->where('language_id', $default_language->id)->where('is_feature',1)->limit(6)->get();
				?>   
					
							
							
						  <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   	
                        <div class="col-sm-4 col-md-4">
                            <div class="Name-again box-shadow">
                                <div class="image-again"> 
								<a href="<?php echo e(route('frontend.postBySubcategory.details',[$row->id,$row->slug])); ?>">
								<img width="600" height="337" src="<?php echo e(asset('assets/images/post/'.$row->image_big)); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" /></a>
                                    <h4 class="sgl-hadding"> <a href="<?php echo e(route('frontend.postBySubcategory.details',[$row->id,$row->slug])); ?>"><?php echo e(strlen($row->title)>60 ? mb_substr($row->title,0,60,"utf-8") : $row->title); ?>প	</a> </h4>
                                </div>
                            </div>
                        </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
					   	
                        
						
						
                        
							
                    </div>
					
					<div class="add">
						 					</div>
					
					
                </div>
                <div class="col-md-4 col-sm-4">
                    <div class="tab-header">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs nav-justified" role="tablist">
								<li role="presentation" class="active"><a href="#tab21" aria-controls="tab21" role="tab" data-toggle="tab" aria-expanded="false"><?php echo e(__('Latest News')); ?></a></li>
								<li role="presentation" ><a href="#tab22" aria-controls="tab22" role="tab" data-toggle="tab" aria-expanded="true"> <?php echo e(__('Featured News')); ?> </a></li>
							</ul>

                            <!-- Tab panes -->
                            <div class="tab-content ">
                                <div role="tabpanel" class="tab-pane in active" id="tab21">

                                    <div class="news-titletab">
									                 <?php
				$latest=DB::table('posts')->inRandomOrder()->orderBy('id','DESC')->where('language_id', $default_language->id)->where('is_trending',1)->limit(10)->get();
				?> 
										<?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <div class="imagr-border">
											<div class="small-imgae">
												<a href="<?php echo e(route('frontend.postBySubcategory.details',[$row->id,$row->slug])); ?>"> <img width="480" height="250" src="<?php echo e(asset('assets/images/post/'.$row->image_big)); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="<?php echo e(asset('assets/images/post/'.$row->image_big)); ?> 480w, <?php echo e(asset('assets/images/post/'.$row->image_big)); ?> 300w" sizes="(max-width: 480px) 100vw, 480px" /> </a>
											</div>
											<div class="hadding_02">
											   <a href="<?php echo e(route('frontend.postBySubcategory.details',[$row->id,$row->slug])); ?>"><?php echo e(strlen($row->title)>60 ? mb_substr($row->title,0,60,"utf-8") : $row->title); ?> </a>
											</div>
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
											
                                        
										
																				
                                    </div> 
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="tab22">                                      
                                    <div class="news-titletab">
                                                       <?php
				$alocito1=DB::table('posts')->inRandomOrder()->orderBy('id','DESC')->where('language_id', $default_language->id)->where('is_slider',1)->limit(1)->get();
				$alocito2=DB::table('posts')->inRandomOrder()->orderBy('id','DESC')->where('language_id', $default_language->id)->where('is_slider',1)->skip(1)->limit(10)->get();
				?>
				
				<?php $__currentLoopData = $alocito2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									    <div class="imagr-border">
											<div class="small-imgae">
												<a href="<?php echo e(route('frontend.postBySubcategory.details',[$row->id,$row->slug])); ?>"> <img width="480" height="250" src="<?php echo e(asset('assets/images/post/'.$row->image_big)); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="<?php echo e(asset('assets/images/post/'.$row->image_big)); ?> 480w, <?php echo e(asset('assets/images/post/'.$row->image_big)); ?> 300w" sizes="(max-width: 480px) 100vw, 480px" /> </a>
											</div>
											<div class="hadding_02">
											   <a href="<?php echo e(route('frontend.postBySubcategory.details',[$row->id,$row->slug])); ?>"><?php echo e(strlen($row->title)>60 ? mb_substr($row->title,0,60,"utf-8") : $row->title); ?></a>
											</div>
										</div>
									      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
									   
									   
									   	
                                    </div>                                          
                                </div>
                            </div>
                        </div>
					
					<div class="add">
						 <div class="widget_area">			<div class="textwidget"><?php echo $gs->sidebar_ads1; ?></div>
		</div>					</div>
							
                </div>
            </div>
			

         </section>   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/creativedesignbd/news2.creativedesign.com.bd/project/resources/views/frontend/details.blade.php ENDPATH**/ ?>