
<?php $__env->startSection('contents'); ?>
 <?php $__env->startSection('meta'); ?>
<title>অবস্থানভিত্তিক খবর</title>
<meta property="og:title" content="অবস্থানভিত্তিক খবর" />
<meta property="og:image" content="<?php echo e(asset('assets/images/'.$gs->og_baner)); ?>" />
<?php $__env->stopSection(); ?>	 


 <!--==================================
               archive-page-section start
         ===================================-->

         <section class="archive-page-section">
		 
            
                    <div class="row">
                
                        <div class="col-md-8 col-sm-8">
										    <!--Next Pages Close--->

<div class="category_info">
<a href=""><i class="fa fa-home" aria-hidden="true"></i> 
			</a> 
<i class="fa fa-chevron-right"></i> <?php echo e($division->name ?? ''); ?> 
<i class="fa fa-chevron-right"></i> <?php echo e($district->name ?? ''); ?> 
<i class="fa fa-chevron-right"></i> <?php echo e($upazila->name ?? ''); ?>

</div>
			   
                        <?php if($posts->count() > 0): ?>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	   		   
		<div class="archive_page archive_back">
		    <div class="col-md-4 col-sm-4">
		        <!-- Post Image Code Start--> 
					<img width="480" height="250" src="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="<?php echo e(asset('assets/images/post/'.$post->image_big)); ?> 480w, <?php echo e(asset('assets/images/post/'.$post->image_big)); ?> 300w" sizes="(max-width: 480px) 100vw, 480px" />					<!-- Post Image Code Close-->
					
		    </div>
		    <div class="col-md-8 col-sm-8">
		        <h3 class="archive_title01"><a href="<?php echo e(route('frontend.postBySubcategory.details',[$post->category->slug,$post->slug])); ?>"><?php echo e(strlen($post->title)>100 ? mb_substr($post->title,0,100,'utf-8').'...' : $post->title); ?> </a></h3>
							
                       <?php echo e(strlen($post->short_description)>250 ? mb_substr($post->short_description,0,250,'utf-8').'...' : $post->short_description); ?> <h4 class="archvie_more"><a href="<?php echo e(route('frontend.postBySubcategory.details',[$post->category->slug,$post->slug])); ?>"><?php echo e(__('Details')); ?>...</a></h4>
                       
		    </div>
		</div>
			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <?php else: ?>
                                <div class="col-lg-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <p class="text-danger text-danger text-center"><?php echo e(__('No information found.')); ?></p>
                                        </div>
                                    </div>
                                </div>
                        <?php endif; ?>
	 		   		   
		
			    
	 	
	 

                    
                    
 <?php if($posts->hasPages()): ?>
    <div class="custom-pagination text-center mt-4 mb-4">
        <ul class="pagination-list">
            
            <?php if($posts->onFirstPage()): ?>
                <li class="disabled"><span>« <?php echo e(__('Previous')); ?></span></li>
            <?php else: ?>
                <li><a href="<?php echo e($posts->previousPageUrl()); ?>" rel="prev">« <?php echo e(__('Previous')); ?></a></li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $posts->links()->elements[0] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $posts->currentPage()): ?>
                    <li class="active"><span><?php echo e($page); ?></span></li>
                <?php else: ?>
                    <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($posts->hasMorePages()): ?>
                <li><a href="<?php echo e($posts->nextPageUrl()); ?>" rel="next"><?php echo e(__('Next')); ?> »</a></li>
            <?php else: ?>
                <li class="disabled"><span><?php echo e(__('Next')); ?> »</span></li>
            <?php endif; ?>
        </ul>
    </div>
<?php endif; ?>
						</div>
                        
                  <div class="col-md-4 col-sm-4">
                    <div class="tab-header">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs nav-justified" role="tablist">
								<li role="presentation" class="active"><a href="#tab21" aria-controls="tab21" role="tab" data-toggle="tab" aria-expanded="false"><?php echo e(__('Latest News')); ?></a></li>
								<li role="presentation" ><a href="#tab22" aria-controls="tab22" role="tab" data-toggle="tab" aria-expanded="true"> <?php echo e(__('Featured News')); ?> </a></li>
							</ul>

                            <!-- Tab panes -->
                            <div class="tab-content ">
                                <div role="tabpanel" class="tab-pane in active" id="tab21">

                                    <div class="news-titletab">
									                                                        <?php
					$secondcat=DB::table('categories')->where('language_id', $default_language->id)->where('parent_id',null)->skip(1)->first();
					$secondcatpostbig=DB::table('posts')->where('category_id',$secondcat->id)->where('is_trending',1)->orderBy('id','DESC')->get();
					$secondcatpostsmall=DB::table('posts')->where('category_id',$secondcat->id)->where('is_trending',1)->orderBy('id','DESC')->skip(1)->limit(20)->get();
					?>  
									
										<?php $__currentLoopData = $secondcatpostbig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                                        <div class="imagr-border">
											<div class="small-imgae">
												<a href="<?php echo e(route('frontend.postBySubcategory.details',[$row->id,$row->slug])); ?>"> <img width="480" height="250" src="<?php echo e(asset('assets/images/post/'.$row->image_big)); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="<?php echo e(asset('assets/images/post/'.$row->image_big)); ?> 480w, <?php echo e(asset('assets/images/post/'.$row->image_big)); ?> 300w" sizes="(max-width: 480px) 100vw, 480px" /> </a>
											</div>
											<div class="hadding_02">
											   <a href="<?php echo e(route('frontend.postBySubcategory.details',[$row->id,$row->slug])); ?>"><?php echo e(strlen($row->title)>60 ? mb_substr($row->title,0,60,"utf-8") : $row->title); ?></a>
											</div>
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
                                        
										
																				
                                    </div> 
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="tab22">                                      
                                    <div class="news-titletab">
                                                                                                         <?php
					$thirdcat=DB::table('categories')->where('language_id', $default_language->id)->where('parent_id',null)->skip(2)->first();
					$thirdcatpostbig=DB::table('posts')->where('category_id',$thirdcat->id)->where('is_trending',1)->orderBy('id','DESC')->limit(1)->get();
					$thirdcatpostsmall=DB::table('posts')->where('category_id',$thirdcat->id)->where('is_trending',1)->orderBy('id','DESC')->skip(1)->limit(20)->get();
					?> 
									   											 <?php $__currentLoopData = $thirdcatpostbig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="imagr-border">
											<div class="small-imgae">
												<a href="<?php echo e(route('frontend.postBySubcategory.details',[$row->id,$row->slug])); ?>"> <img width="480" height="250" src="<?php echo e(asset('assets/images/post/'.$row->image_big)); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" srcset="<?php echo e(asset('assets/images/post/'.$row->image_big)); ?> 480w, <?php echo e(asset('assets/images/post/'.$row->image_big)); ?> 300w" sizes="(max-width: 480px) 100vw, 480px" /> </a>
											</div>
											<div class="hadding_02">
											   <a href="<?php echo e(route('frontend.postBySubcategory.details',[$row->id,$row->slug])); ?>"><?php echo e(strlen($row->title)>60 ? mb_substr($row->title,0,60,"utf-8") : $row->title); ?></a>
											</div>
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
										
										
										
										
                                    </div>                                          
                                </div>
                            </div>
                        </div>
					
					<div class="add">
						 <div class="widget_area">			<div class="textwidget"><?php echo $gs->sidebar_ads1; ?></div>
		</div>					</div>
							
                </div>
				
				
                </div>
   
         </section>
 
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/creativedesignbd/news2.creativedesign.com.bd/project/resources/views/frontend/location_news.blade.php ENDPATH**/ ?>