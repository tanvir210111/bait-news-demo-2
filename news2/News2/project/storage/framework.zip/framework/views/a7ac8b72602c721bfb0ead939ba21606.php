

<?php $__env->startSection('content'); ?>
<input type="hidden" id="headerdata" value="<?php echo e(__('CATEGORY')); ?>">
<input type="hidden" id="attribute_data" value="<?php echo e(__('ADD NEW ATTRIBUTE')); ?>">
<div class="content-area">
    <div class="mr-breadcrumb">
        <div class="row">
            <div class="col-lg-12">
                <h4 class="heading"><?php echo e(__('All Posts')); ?></h4>
                <ul class="links">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?> </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('slider.index')); ?>"><?php echo e(__('Posts')); ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-lg-12 text-right">
            <a href="<?php echo e(route('post.index')); ?>" class="btn btn-primary btn-sm"><?php echo e(__('All Posts')); ?></a>
        </div>
    </div>
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6">
                <a href="<?php echo e(route('article.create')); ?>" class="add-post-area">
                   <div class="icon">
                    <i class="far fa-file-alt"></i>
                   </div>
                   <h6>
                       <?php echo e(__('Article')); ?>

                   </h6>
                   <p><?php echo e(__('An article with images')); ?></p>
                </a>
            </div>
            <div class="col-lg-4 col-md-6">
               <a href="<?php echo e(route('image.album.index')); ?>" class="add-post-area">
                <div class="icon">
                    <i class="far fa-images"></i>
                </div>
                <h6>
                    <?php echo e(__('Gallery')); ?>

                </h6>
                <p><?php echo e(__('A collection of images')); ?></p>
            </a>
            </div>
            <div class="col-lg-4 col-md-6">
            <a href="/admin/rss" class="add-post-area">
                <div class="icon">
                    <i class="fas fa-rss"></i>
                </div>
                <h6>
                    <?php echo e(__('Rss Feed')); ?>

                </h6>
                <p><?php echo e(__('RSS Feeds article')); ?></p>
            </a>
            </div>

            <div class="col-lg-4 col-md-6">
                <a href="/admin/schedule" class="add-post-area">
                 <div class="icon">
                    <i class="fa fa-calendar"></i>
                 </div>
                 <h6>
                     <?php echo e(__('Schedule Post')); ?>

                 </h6>
                 <p><?php echo e(__('All Schedule Post')); ?></p>
             </a>
             </div>

            <div class="col-lg-4 col-md-6">
            <a href="<?php echo e(route('video.create')); ?>" class="add-post-area">
                <div class="icon">
                    <i class="fas fa-film"></i>
                </div>
                <h6>
                    <?php echo e(__('Video')); ?>

                </h6>
                <p><?php echo e(__('Upload or embed videos')); ?></p>
            </a>
            </div>
            <div class="col-lg-4 col-md-6">
                <a href="<?php echo e(route('audio.create')); ?>" class="add-post-area">
                    <div class="icon">
                        <i class="fas fa-volume-up"></i>
                    </div>
                    <h6>
                        <?php echo e(__('Audio')); ?>

                    </h6>
                    <p><?php echo e(__('Upload audios')); ?></p>
                </a>
            </div>
        </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/admin/post/format.blade.php ENDPATH**/ ?>