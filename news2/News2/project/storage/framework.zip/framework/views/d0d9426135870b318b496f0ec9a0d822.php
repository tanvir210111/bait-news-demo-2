
 <?php $__env->startSection('meta'); ?>
    <title><?php echo e(__('Video Gallery')); ?></title>
<meta property="og:title" content="<?php echo e(__('Video Gallery')); ?>" />
<meta property="og:image" content="<?php echo e(asset('assets/images/'.$gs->og_baner)); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
 

		<!----------__________ photogallary start ___________------------>
			
			
				<div class="row">
					<div class="photogallary">				
						                   <?php
				$video2=DB::table('posts')->inRandomOrder()->orderBy('id','DESC')->where('language_id', $default_language->id)->where('is_videoGallery',1)->limit(100000)->get();
				?>  
						 
        						                     <?php if($video2->count()>0): ?>
										<?php $__currentLoopData = $video2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3 col-sm-3">
							<div class="gallary">
							<div class="embed-responsive embed-responsive-16by9 	embed-responsive-item" style="margin-bottom:0px; margin-top:5px;">
									<p><iframe src="https://www.youtube.com/embed/<?php echo e($row->embed_video); ?>" width="263" height="148" frameborder="0" allowfullscreen="allowfullscreen"></iframe></p>
								</div>
								<h4 class="photo_title"><a href="https://www.youtube.com/watch?v=<?php echo e($row->embed_video); ?>"><?php echo e(strlen($row->title)>40 ? mb_substr($row->title,0,40,"utf-8") : $row->title); ?></a></h4>
							</div>
						</div>
						      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
									<?php else: ?> 
										
														<div class="col-md-3 col-sm-3">
							<div class="gallary">
							<div class="embed-responsive embed-responsive-16by9 	embed-responsive-item" style="margin-bottom:0px; margin-top:5px;">
									<p><iframe src="https://www.youtube.com/embed/1GdR_JEnBwo" width="263" height="148" frameborder="0" allowfullscreen="allowfullscreen"></iframe></p>
								</div>
								<h4 class="photo_title"><a href="archives/videogallery/%e0%a6%9a%e0%a6%b2%e0%a6%a8%e0%a6%be-%e0%a6%b8%e0%a7%81%e0%a6%9c%e0%a6%a8.html">কোন ভিডিও নেই</a></h4>
							</div>
						</div>
 <?php endif; ?>								
								
						
						
						


    <!-- options -->
    <div class="col-md-12 options border-bottom">

        <!-- pagination -->
        <ul class="pagination pull-left">
		<li></li>
            <li></li>
            
        </ul>

    </div>
    <!-- /.options -->  

    
    						
					</div>
				</div>


  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/creativedesignbd/news2.creativedesign.com.bd/project/resources/views/frontend/video.blade.php ENDPATH**/ ?>