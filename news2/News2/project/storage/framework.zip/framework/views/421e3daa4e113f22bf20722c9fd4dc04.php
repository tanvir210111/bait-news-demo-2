

<?php $__env->startPush('css'); ?>
<style>
body {
    background: #eef2f7;
    font-family: 'Noto Sans Bengali', 'Poppins', sans-serif;
}

/* -------- HEADER -------- */
.polls-header {
    text-align: center;
    padding: 70px 0 30px;
}

.polls-header h2 {
    font-size: 2.4rem;
    font-weight: 800;
    color: #0a3d62;
}

.polls-header p {
    color: #6c757d;
    font-size: 1.05rem;
}

/* -------- POLL CARD -------- */
.poll-card {
    background: #ffffff;
    border-radius: 18px;
    padding: 40px 35px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.07);
    margin-bottom: 35px;
    transition: 0.3s;
    border: 1px solid #e8edf3;
    position: relative;
    overflow: hidden;
}
.poll-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 14px 50px rgba(0,0,0,0.12);
}

.poll-card::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    height: 5px;
    width: 100%;
    background: linear-gradient(90deg, #007bff, #00c6ff);
}

.poll-card h5 {
    font-size: 1.35rem;
    font-weight: 700;
    color: #222;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
}
.poll-card h5 i {
    color: #007bff;
    margin-right: 8px;
}

/* -------- OPTIONS -------- */
.option {
    margin-bottom: 20px;
}
.option-label {
    display: flex;
    justify-content: space-between;
    font-weight: 500;
    color: #343a40;
    margin-bottom: 8px;
}
.option-label span:last-child {
    font-weight: 600;
    color: #007bff;
}

/* -------- PROGRESS BAR -------- */
.progress {
    height: 14px;
    background: #e9ecef;
    border-radius: 10px;
    overflow: hidden;
}
.progress-bar {
    height: 100%;
    border-radius: 10px;
    background: linear-gradient(90deg, #007bff 0%, #00c6ff 100%);
    animation: growBar 1.2s ease forwards;
}
@keyframes growBar {
    from { width: 0; }
    to { width: var(--bar-width); }
}

/* -------- FOOTER TEXT -------- */
.total-vote {
    text-align: right;
    font-size: 0.95rem;
    font-weight: 500;
    color: #6c757d;
    margin-top: 20px;
}

.no-vote {
    text-align: center;
    background: #f8f9fa;
    border-radius: 12px;
    padding: 20px;
    font-style: italic;
    color: #999;
}

.polls-footer {
    text-align: center;
    margin-top: 50px;
    color: #adb5bd;
    font-size: 0.9rem;
}

.polls-footer i {
    color: #ffb703;
}

/* -------- Responsive -------- */
@media (max-width: 768px) {
    .poll-card {
        padding: 25px 20px;
    }
    .polls-header h2 {
        font-size: 1.8rem;
    }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('contents'); ?>
<section class="polls-page">
    <div class="container">
        <div class="polls-header">
            <h2><i class="fas fa-chart-bar text-primary me-2"></i><?php echo e(__('Poll Results')); ?></h2>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-10">
                <?php $__empty_1 = true; $__currentLoopData = $polls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="poll-card">
                        <h5><i class="far fa-question-circle"></i><?php echo e($poll->question); ?></h5>

                        <?php
                            $results = \App\Models\PollResult::where('poll_question_id', $poll->id)->get();
                            $totalVotes = $results->count();
                            $grouped = $results->groupBy('poll_answer_id');
                        ?>

                        <?php if($totalVotes > 0): ?>
                            <?php $__currentLoopData = $grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answerId => $votes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $answer = \App\Models\PollAnswer::find($answerId);
                                    $answerText = $answer ? $answer->poll_option : __('Deleted');
                                    $percent = round(($votes->count() / $totalVotes) * 100, 2);
                                ?>
                                <div class="option">
                                    <div class="option-label">
                                        <span><?php echo e($answerText); ?></span>
                                        <span><?php echo e($percent); ?>%</span>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-striped progress-bar-animated"
                                            style="--bar-width: <?php echo e($percent); ?>%; width: <?php echo e($percent); ?>%;">
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="no-vote"><?php echo e(__('No votes yet — be the first to participate!')); ?></div>
                        <?php endif; ?>

                        <p class="total-vote">
                            <i class="far fa-user me-1"></i><?php echo e(__('Total Votes')); ?>: <?php echo e($totalVotes); ?>

                        </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="no-vote"><?php echo e(__('No active polls available at the moment.')); ?></div>
                <?php endif; ?>

                <div class="polls-footer">
                    <i class="fas fa-sync-alt me-1"></i> <?php echo e(__('Poll data updates every few minutes automatically.')); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/creativedesignbd/news2.creativedesign.com.bd/project/resources/views/frontend/all_poll.blade.php ENDPATH**/ ?>