

<li>
    <a href="#page" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-window-restore"></i><?php echo e(__('Pages')); ?>

    </a>
    <ul class="collapse list-unstyled" id="page" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('admin.page.create')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Add Page')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.page.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Pages')); ?></span></a>
        </li>
    </ul>
</li>


<li>
    <a href="#menu2" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-folder-open"></i><?php echo e(__('Categories')); ?>

    </a>
    <ul class="collapse list-unstyled" id="menu2" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('categories.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Categories')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('subcategories.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('SubCategories')); ?></span></a>
        </li>
    </ul>
</li>
<li>
    <a href="#geo" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-globe-asia"></i><?php echo e(__('Location')); ?>

    </a>
    <ul class="collapse list-unstyled" id="geo" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('division.index')); ?>">
                <span><i class="fas fa-angle-double-right"></i><?php echo e(__('Divisions')); ?></span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('district.index')); ?>">
                <span><i class="fas fa-angle-double-right"></i><?php echo e(__('Districts')); ?></span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('upazila.index')); ?>">
                <span><i class="fas fa-angle-double-right"></i><?php echo e(__('Upazilas')); ?></span>
            </a>
        </li>
    </ul>
</li>


<li>
    <a href="<?php echo e(route('admin.post.format')); ?>" >
        <i class="fa fa-file"></i><?php echo e(__('Add Post')); ?>

    </a>
</li>
 
<li>
    <a href="#poll" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-list"></i><?php echo e(__('Polls')); ?>

    </a>
    <ul class="collapse list-unstyled" id="poll" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('addPolls.create')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Add Polls')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('addPolls.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Polls')); ?></span></a>
        </li>
    </ul>
</li>



<li>
    <a href="<?php echo e(route('image.album.index')); ?>" >
        <i class="fas fa-image"></i><?php echo e(__('Images Gallery')); ?>

    </a>
</li>


<li>
    <a href="#menu4" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-bars"></i><?php echo e(__('Posts')); ?>

    </a>
    <ul class="collapse list-unstyled" id="menu4" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('post.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('All Posts')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('slider.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Slider Posts')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('feature.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Featured Posts')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('breaking.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Breaking News')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('pending.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Pending Posts')); ?></span></a>
        </li>

    </ul>
</li>

<li>
    <a href="<?php echo e(route('schedule.index')); ?>"><span><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e(__('Schedule Post')); ?></span></a>
</li>



<li>
    <a href="<?php echo e(route('draft.index')); ?>"><span><i class="fab fa-firstdraft"></i><?php echo e(__('Drafts')); ?></span></a>
</li>


<li>
    <a href="#rss" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-rss"></i><?php echo e(__('Rss Feeds')); ?>

    </a>
    <ul class="collapse list-unstyled" id="rss" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('rss.create')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Import Rss Feeds')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('rss.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Rss Feeds')); ?></span></a>
        </li>
    </ul>
</li>

  
<li>
    <a href="#poll" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-list"></i><?php echo e(__('Polls')); ?>

    </a>
    <ul class="collapse list-unstyled" id="poll" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('addPolls.create')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Add Polls')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('addPolls.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Polls')); ?></span></a>
        </li>
    </ul>
</li>


<li>
    <a href="#widget" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-tachometer-alt"></i><?php echo e(__('Widgets')); ?>

    </a>
    <ul class="collapse list-unstyled" id="widget" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('widget.create')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Add Widgets')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('widget.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Widgets')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('widget.settings')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Widget Settings')); ?></span></a>
        </li>
    </ul>
</li>

 


 
<li>
    <a href="#menu9" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-envelope"></i><?php echo e(__('NewsLetter')); ?>

    </a>
    <ul class="collapse list-unstyled" id="menu9" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('admin.subscriber.email')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Send Email')); ?></span></a>
        </li>

        <li>
            <a href="<?php echo e(route('admin.subscriber.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('All Subscribers')); ?></span></a>
        </li>
    </ul>
</li>


<li>
    <a href="#menu10" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fa fa-language"></i><?php echo e(__('Languages')); ?>

    </a>
    <ul class="collapse list-unstyled" id="menu10" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('admin.language.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Language')); ?></span></a>
        </li>

        <li>
            <a href="<?php echo e(route('admin.admin_language.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Admin Language')); ?></span></a>
        </li>
    </ul>
</li>



  
<li>
    <a href="#general" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-cogs"></i><?php echo e(__('General Settings')); ?>

    </a>
	

	
    <ul class="collapse list-unstyled" id="general" data-parent="#accordion">
	
	
		        <li>
            <a href="<?php echo e(route('admin.generalsettings.websiteContent')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Website settings & Adds')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.generalsettings.logo')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Logo')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.languagelogo.index')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Language Base Logo')); ?></span></a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.generalsettings.favicon')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Favicon')); ?></span></a>
        </li>





    </ul>
</li>

<li>
    <a href="<?php echo e(route('social.link.index')); ?>" class=" wave-effect"><i class="fas fa-paper-plane"></i><?php echo e(__('Social Settings')); ?></a>
</li>


   


  
<li>
    <a href="#emails" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-at"></i><?php echo e(__('Email Settings')); ?>

    </a>
    <ul class="collapse list-unstyled" id="emails" data-parent="#accordion">
        <li><a href="<?php echo e(route('admin.email.config')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Email Configurations')); ?></span></a></li>  
    </ul>
</li>


<li>
    <a href="#seoTools" class="accordion-toggle wave-effect" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-wrench"></i><?php echo e(__('SEO Tools')); ?>

    </a>
    <ul class="collapse list-unstyled" id="seoTools" data-parent="#accordion">
        <li>
            <a href="<?php echo e(route('seo.google.analytics')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Google Analytics')); ?></span></a>
        </li
        >
        <li>
            <a href="<?php echo e(route('seo.meta.keywords')); ?>"><span><i class="fas fa-angle-double-right"></i><?php echo e(__('Website Meta Keywords')); ?></span></a>
        </li>
    </ul>
</li>

<li>
    <a href="<?php echo e(route('admin.sitemap.all')); ?>" class=" wave-effect"><i class="fas fa-sitemap"></i><?php echo e(__('Site Map')); ?></a>
</li>
   
<li>
    <a href="<?php echo e(route('fonts.index')); ?>" class=" wave-effect"><i class="fa fa-font"></i><?php echo e(__('Font Option')); ?></a>
</li>



<li>
    <a href="<?php echo e(route('admin.staff.index')); ?>" class=" wave-effect"><i class="fas fa-user-tag"></i><?php echo e(__('Reporters')); ?></a>
</li>  

<li>
    <a href="<?php echo e(route('admin.cache.clear')); ?>" class=" wave-effect"><i class="fa fa-database"></i><?php echo e(__('Clear Cache')); ?></a>
</li>    <?php /**PATH /home/creativedesignbd/news2.creativedesign.com.bd/project/resources/views/partial/admin-role/super.blade.php ENDPATH**/ ?>