<?php $__env->startSection('content'); ?>

<div class="content-area">
              <div class="mr-breadcrumb">
                <div class="row">
                  <div class="col-lg-12">
                      <h4 class="heading"><?php echo e(__('Website Contents')); ?></h4>
                    <ul class="links">
                      <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?> </a>
                      </li>
                      <li>
                        <a href="javascript:;"><?php echo e(__('General Settings')); ?></a>
                      </li>
                      <li>
                        <a href=""><?php echo e(__('Website Contents')); ?></a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="add-product-content">
                <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row">
                  <div class="col-lg-12">
                    <div class="product-description">
                      <div class="body-area">
                      <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
                      <form class="uplogo-form" id="geniusform" action="<?php echo e(route('admin.generalsettings.update')); ?>"  method="POST" enctype="multipart/form-data">
                          <?php echo e(csrf_field()); ?>


                        <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('Website Title')); ?> *
                                  </h4>
                            </div>
                          </div>
                          <div class="col-lg-6">
                            <input type="text" class="input-field" placeholder="<?php echo e(__('Write Your Site Title Here')); ?>" name="title" value="<?php echo e($data->title); ?>" required="">
                          </div>
                        </div>
                        <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('Email')); ?> *
                                  </h4>
                            </div>
                          </div>
                          <div class="col-lg-6">
                            <input type="text" class="input-field" placeholder="<?php echo e(__('Write Your Email Address')); ?>" name="email" value="<?php echo e($data->email); ?>" required="">
                          </div>
                        </div>

                                               <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('Primary Color')); ?> *</h4>
                            </div>
                          </div>
                          <div class="col-lg-6">
                              <div class="form-group">
                                <div class="input-group colorpicker-component cp">
                                <input type="text" class="form-control input-field color-field cp" name="theme_color" value="<?php echo e($data->theme_color); ?>"/>
                                  <span class="input-group-addon"><i></i></span>
                                </div>
                              </div>

                          </div>
                        </div>
						
						
						
						
						
						
						
			                        <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('Menu Default Color')); ?> *</h4>
                            </div>
                          </div>
                          <div class="col-lg-6">
                              <div class="form-group">
                                <div class="input-group colorpicker-component cp">
                                <input type="text" class="form-control input-field color-field cp" name="menu_active" value="<?php echo e($data->menu_active); ?>"/>
                                  <span class="input-group-addon"><i></i></span>
                                </div>
                              </div>

                          </div>
                        </div>			
						
						
						
						                        <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('Menu Main Color')); ?> *</h4>
                            </div>
                          </div>
                          <div class="col-lg-6">
                              <div class="form-group">
                                <div class="input-group colorpicker-component cp">
                                <input type="text" class="form-control input-field color-field cp" name="menu_color" value="<?php echo e($data->menu_color); ?>"/>
                                  <span class="input-group-addon"><i></i></span>
                                </div>
                              </div>

                          </div>
                        </div>
						
						
						                        <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('Menu 2 Color')); ?> *</h4>
                            </div>
                          </div>
                          <div class="col-lg-6">
                              <div class="form-group">
                                <div class="input-group colorpicker-component cp">
                                <input type="text" class="form-control input-field color-field cp" name="menu_color2" value="<?php echo e($data->menu_color2); ?>"/>
                                  <span class="input-group-addon"><i></i></span>
                                </div>
                              </div>

                          </div>
                        </div>
						
						
						
						
						
						
						
						
						
						
						

                        <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('Category Side Color')); ?> *</h4>
                            </div>
                          </div>
                          <div class="col-lg-6">
                              <div class="form-group">
                                <div class="input-group colorpicker-component cp">
                                  <input type="text" class="form-control input-field color-field cp" name="catergory_side" value="<?php echo e($data->catergory_side); ?>" />
                                  <span class="input-group-addon"><i></i></span>
                                </div>
                              </div>
                          </div>
                        </div>
                        <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('Button Color')); ?> *</h4>
                            </div>
                          </div>
                          <div class="col-lg-6">
                              <div class="form-group">
                                <div class="input-group colorpicker-component cp">
                                <input type="text" class="form-control input-field color-field cp" name="buton_color" value="<?php echo e($data->buton_color); ?>"/>
                                  <span class="input-group-addon"><i></i></span>
                                </div>
                              </div>

                          </div>
                        </div>




                        <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('Footer Dot Line Color')); ?> *</h4>
                            </div>
                          </div>
                          <div class="col-lg-6">
                              <div class="form-group">
                                <div class="input-group colorpicker-component cp">
                                  <input type="text" class="form-control input-field color-field cp" name="footer_line" value="<?php echo e($data->footer_line); ?>" />
                                  <span class="input-group-addon"><i></i></span>
                                </div>
                              </div>
                          </div>
                        </div>


                        <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('Footer Color')); ?> *</h4>
                            </div>
                          </div>
                          <div class="col-lg-6">
                              <div class="form-group">
                                <div class="input-group colorpicker-component cp">
                                  <input type="text" class="form-control input-field color-field cp" name="footer_color" value="<?php echo e($data->footer_color); ?>" />
                                  <span class="input-group-addon"><i></i></span>
                                </div>
                              </div>
                          </div>
                        </div>
						
						
					<div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('E-Paper Link')); ?> *
                                  </h4>
                            </div>
                          </div>
                          <div class="col-lg-6">
                            <input type="text" class="input-field" placeholder="<?php echo e(__('Epaper Link here')); ?>" name="epaper_link" value="<?php echo e($data->epaper_link); ?>" required="">
                          </div>
                        </div>
						
						
						
						                        <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('Facebook Page URL')); ?> *
                                  </h4>
                            </div>
                          </div>
                          <div class="col-lg-6">
                            <input type="text" class="input-field" placeholder="<?php echo e(__('Write Your Page URL')); ?>" name="facebook_page_link" value="<?php echo e($data->facebook_page_link); ?>" required="">
                          </div>
                        </div>
						 <div class="row justify-content-center">
                            <div class="col-lg-3">
                              <div class="left-area">
                                <h4 class="heading">
                                    <?php echo e(__('Facebook Page (ON/OFF)')); ?>

                                </h4>
                              </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="action-list">
                                    <select class="process select droplinks <?php echo e($data->is_facebook == 1 ? 'drop-success' : 'drop-danger'); ?>" name="is_facebook" id="is_facebook">
                                      <option value="1" <?php echo e($data->is_facebook == 1 ? 'selected' : ''); ?>><?php echo e(__('Activated')); ?></option>
                                      <option value="0" <?php echo e($data->is_facebook == 0 ? 'selected' : ''); ?>><?php echo e(__('Deactivated')); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>
						
						
						
						
						
						
						
					<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Live TV *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="live_tv" required=""><?php echo e($data->live_tv); ?></textarea>
                                  </div>
                              </div>
                            </div>

                        <div class="row justify-content-center">
                            <div class="col-lg-3">
                              <div class="left-area">
                                <h4 class="heading">
                                    <?php echo e(__('Live TV (ON/OFF)')); ?>

                                </h4>
                              </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="action-list">
                                    <select class="process select droplinks <?php echo e($data->is_live_tv == 1 ? 'drop-success' : 'drop-danger'); ?>" name="is_live_tv" id="is_live_tv">
                                      <option value="1" <?php echo e($data->is_live_tv == 1 ? 'selected' : ''); ?>><?php echo e(__('Activated')); ?></option>
                                      <option value="0" <?php echo e($data->is_live_tv == 0 ? 'selected' : ''); ?>><?php echo e(__('Deactivated')); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <div class="row justify-content-center">
                            <div class="col-lg-3">
                              <div class="left-area">
                                <h4 class="heading">
                                    <?php echo e(__('Map (ON/OFF)')); ?>

                                </h4>
                              </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="action-list">
                                    <select class="process select droplinks <?php echo e($data->is_map == 1 ? 'drop-success' : 'drop-danger'); ?>" name="is_map" id="is_map">
                                      <option value="1" <?php echo e($data->is_map == 1 ? 'selected' : ''); ?>><?php echo e(__('Activated')); ?></option>
                                      <option value="0" <?php echo e($data->is_map == 0 ? 'selected' : ''); ?>><?php echo e(__('Deactivated')); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>











					<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Notice *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="notice_text" required=""><?php echo e($data->notice_text); ?></textarea>
                                  </div>
                              </div>
                            </div>



                        <div class="row justify-content-center">
                            <div class="col-lg-3">
                              <div class="left-area">
                                <h4 class="heading">
                                    <?php echo e(__('Notice (ON/OFF)')); ?>

                                </h4>
                              </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="action-list">
                                    <select class="process select droplinks <?php echo e($data->is_notice == 1 ? 'drop-success' : 'drop-danger'); ?>" name="is_notice" id="is_notice">
                                      <option value="1" <?php echo e($data->is_notice == 1 ? 'selected' : ''); ?>><?php echo e(__('Activated')); ?></option>
                                      <option value="0" <?php echo e($data->is_notice == 0 ? 'selected' : ''); ?>><?php echo e(__('Deactivated')); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <div class="row justify-content-center">
                            <div class="col-lg-3">
                              <div class="left-area">
                                <h4 class="heading">
                                    <?php echo e(__('Our National Anthem  (ON/OFF)')); ?>

                                </h4>
                              </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="action-list">
                                    <select class="process select droplinks <?php echo e($data->is_national == 1 ? 'drop-success' : 'drop-danger'); ?>" name="is_national" id="is_national">
                                      <option value="1" <?php echo e($data->is_national == 1 ? 'selected' : ''); ?>><?php echo e(__('Activated')); ?></option>
                                      <option value="0" <?php echo e($data->is_national == 0 ? 'selected' : ''); ?>><?php echo e(__('Deactivated')); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>


						 <div class="row justify-content-center">
                            <div class="col-lg-3">
                              <div class="left-area">
                                <h4 class="heading">
                                    <?php echo e(__('Pool (ON/OFF)')); ?>

                                </h4>
                              </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="action-list">
                                    <select class="process select droplinks <?php echo e($data->is_pool_on == 1 ? 'drop-success' : 'drop-danger'); ?>" name="is_pool_on" id="is_pool_on">
                                      <option value="1" <?php echo e($data->is_pool_on == 1 ? 'selected' : ''); ?>><?php echo e(__('Activated')); ?></option>
                                      <option value="0" <?php echo e($data->is_pool_on == 0 ? 'selected' : ''); ?>><?php echo e(__('Deactivated')); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>




					<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Search Console Verification Code
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="search_console" required=""><?php echo e($data->search_console); ?></textarea>
                                  </div>
                              </div>
                            </div>
							
			<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Adsense Verification Code
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="adsense_code" required=""><?php echo e($data->adsense_code); ?></textarea>
                                  </div>
                              </div>
                            </div>
	<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Header 728X90 Ads *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="horizontal_adds1" required=""><?php echo e($data->horizontal_adds1); ?></textarea>
                                  </div>
                              </div>
                            </div>
							
							
							
													<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Homepage 1 728X90 Ads *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="header1_728" required=""><?php echo e($data->header1_728); ?></textarea>
                                  </div>
                              </div>
                            </div>	
							
														
													<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Homepage 2 728X90 Ads *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="header2_728" required=""><?php echo e($data->header2_728); ?></textarea>
                                  </div>
                              </div>
                            </div>
																				<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Homepage 3 728X90 Ads *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="header3_728" required=""><?php echo e($data->header3_728); ?></textarea>
                                  </div>
                              </div>
                            </div>
							
																											<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Homepage 4 728X90 Ads *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="header4_728" required=""><?php echo e($data->header4_728); ?></textarea>
                                  </div>
                              </div>
                            </div>
							
							
							
							
							
						<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Homepage 1 970X90 Ads *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="homepageads1_970" required=""><?php echo e($data->homepageads1_970); ?></textarea>
                                  </div>
                              </div>
                            </div>	
							
													<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Homepage 2 970X90 Ads *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="homepageads2_970" required=""><?php echo e($data->homepageads2_970); ?></textarea>
                                  </div>
                              </div>
                            </div>
							
							
																				<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Homepage 3 970X90 Ads *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="homepageads3_970" required=""><?php echo e($data->homepageads3_970); ?></textarea>
                                  </div>
                              </div>
                            </div>
							
																											<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Homepage 4 970X90 Ads *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="homepageads4_970" required=""><?php echo e($data->homepageads4_970); ?></textarea>
                                  </div>
                              </div>
                            </div>
							
							
							
							
							
							
						
								<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Sidebar Ads 1 *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="sidebar_ads" required=""><?php echo e($data->sidebar_ads); ?></textarea>
                                  </div>
                              </div>
                            </div>



						<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Sidebar 2 Ads *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="sidebar_ads1" required=""><?php echo e($data->sidebar_ads1); ?></textarea>
                                  </div>
                              </div>
                            </div>


						<div class="row justify-content-center">
                              <div class="col-lg-3">
                                <div class="left-area">
                                    <h4 class="heading">
                                        Sidebar Big Ads *
                                        <p class="sub-heading"><?php echo e((__('In Any Language'))); ?></p>
                                    </h4>
                                  
                                </div>
                              </div>
                              <div class="col-lg-6">
                                  <div class="tawk-area">
                                  <textarea name="sidebar_adsbig" required=""><?php echo e($data->sidebar_adsbig); ?></textarea>
                                  </div>
                              </div>
                            </div>



                            <div class="row justify-content-center">
                            <div class="col-lg-3">
                              <div class="left-area">
                                  <h4 class="heading"><?php echo e(__('TimeZone')); ?> *
                                    </h4>
                              </div>
                            </div>
                            <div class="col-lg-6">
                              <?php
                                $timezone_identifiers =
                                    DateTimeZone::listIdentifiers(DateTimeZone::ALL);

                                echo "<select name='time_zone'>";

                                echo "<option disabled selected>
                                        Please Select Timezone
                                      </option>";

                                $n = 419;
                                for($i = 0; $i < $n; $i++) {
                                  if($data->time_zone == $timezone_identifiers[$i]){
                                        $msg = 'selected';
                                    }else{
                                        $msg = '';
                                    }
                                    echo "<option value='" . $timezone_identifiers[$i] ."' ".$msg.">" . $timezone_identifiers[$i] . "</option>";
                                }

                                echo "</select>";
                              ?>
                            </div>
                          </div>





                        <div class="row justify-content-center">
                          <div class="col-lg-3">
                            <div class="left-area">

                            </div>
                          </div>
                          <div class="col-lg-6">
                            <button class="addProductSubmit-btn" type="submit"><?php echo e(__('Save')); ?></button>
                          </div>
                        </div>
                     </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/admin/js/notify.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/distawk.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/admin/generalsettings/websiteContent.blade.php ENDPATH**/ ?>