<div class="alert alert-info validation" style="display: none;">
    <p class="text-left"></p> 
</div>
<div class="alert alert-success validation" style="display: none;">
<button type="button" class="close alert-close"><span>×</span></button>
    <p class="text-left"></p> 
</div>
<div class="alert alert-danger validation" style="display: none;">
<button type="button" class="close alert-close"><span>×</span></button>
  <p class="text-left"></p> 
</div><?php /**PATH /home/creativedesignbd/news2.creativedesign.com.bd/project/resources/views/includes/validation/form_validation.blade.php ENDPATH**/ ?>