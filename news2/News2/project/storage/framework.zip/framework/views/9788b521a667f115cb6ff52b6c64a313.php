

<?php $__env->startSection('styles'); ?>

<style type="text/css">
  
textarea.input-field {
  padding: 20px 20px 0px 20px;
  border-radius: 0px;
}

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <div class="content-area">
              <div class="mr-breadcrumb">
                <div class="row">
                  <div class="col-lg-12">
                      <h4 class="heading"><?php echo e(__('Edit Language')); ?> <a class="add-btn" href="<?php echo e(route('admin.language.index')); ?>"><i class="fas fa-arrow-left"></i> <?php echo e(__('Back')); ?></a></h4>
                      <ul class="links">
                        <li>
                          <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?> </a>
                        </li>
                        <li><a href="javascript:;"><?php echo e(__('Language Settings')); ?></a></li>
                        <li>
                          <a href="<?php echo e(route('admin.language.index')); ?>"><?php echo e(__('Website Language')); ?></a>
                        </li>
                        <li>
                          <a href="<?php echo e(route('admin.language.edit',$data->id)); ?>"><?php echo e(__('Edit')); ?></a>
                        </li>
                      </ul>
                  </div>
                </div>
              </div>
              <div class="add-product-content">
                <div class="row">
                  <div class="col-lg-12">
                    <?php echo $__env->make('includes.admin.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('includes.admin.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="product-description">
                      <div class="body-area">
                      <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
                      <form id="geniusform" action="<?php echo e(route('admin.language.update',$data->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                         <div class="row">
                          <div class="col-lg-4">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('English')); ?> *</h4>
                                <p class="sub-heading"><?php echo e(__('(In Any Language)')); ?></p>
                            </div>
                          </div>
                          <div class="col-lg-7">
                            <input type="text" class="input-field" name="language" placeholder="<?php echo e(__('Language')); ?>" required="" value="<?php echo e($data->language); ?>">
                          </div>
                        </div>
                        
                        
                        <div class="row">
                          <div class="col-lg-4">
                            <div class="left-area">
                                <h4 class="heading"><?php echo e(__('Language Direction')); ?> *</h4>

                            </div>
                          </div>
                          <div class="col-lg-7">
                            <select name="rtl" class="input-field" required="">
                              <option value="0" <?php echo e($data->rtl == '0'  ? 'selected' : ''); ?>><?php echo e(__('Left To Right')); ?></option>
                              <option value="1" <?php echo e($data->rtl == '1'  ? 'selected' : ''); ?>><?php echo e(__('Right To Left')); ?></option>
                            </select>
                          </div>
                        </div>


                      <hr>
                        
                        <h4 class="text-center"><?php echo e(__('SET LANGUAGE KEYS & VALUES')); ?></h4>

                      <hr>

                        <div class="row">
                          <div class="col-lg-2">
                            <div class="left-area">

                            </div>
                          </div>
                          <div class="col-lg-8">
                            <div class="featured-keyword-area">

                              <div class="lang-tag-top-filds" id="lang-section">


                              <?php $__currentLoopData = $lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="lang-area">
                                 
                                  <div class="row">
                          <div class="col-lg-6">
  <!-- ইউজার যা দেখবে (এডিট করতে পারবে না) -->
  <textarea class="input-field" placeholder="<?php echo e(__('Enter Language Key')); ?>" disabled><?php echo e($key); ?></textarea>

  <!-- ফর্মে সেভ হবে এই ইনপুট -->
  <input type="hidden" name="keys[]" value="<?php echo e($key); ?>">
</div>


                                    <div class="col-lg-6">
                                      <textarea  name="values[]" class="input-field" placeholder="<?php echo e(__('Enter Language Value')); ?>" required=""><?php echo e($val); ?></textarea>
                                    </div>
                                  </div>
                                </div>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              </div>

                              <a href="javascript:;" id="lang-btn" class="add-fild-btn"><i class="icofont-plus"></i> <?php echo e(__('Add More Field')); ?></a>
                            </div>
                          </div>

                          <div class="col-lg-2">
                            <div class="left-area">

                            </div>
                          </div>

                        </div>


                      
                        <div class="row">
                          <div class="col-lg-5">
                            <div class="left-area">
                              
                            </div>
                          </div>
                          <div class="col-lg-7">
                            <button class="addProductSubmit-btn" type="submit"><?php echo e(__('Save')); ?></button>
                          </div>
                        </div>
                      </form>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
  "use strict";
  var lang = {
    'language_key':'<?php echo e(__('Enter Language Key')); ?>',
    'language_value':'<?php echo e(__('Enter Language Key')); ?>',
  }
</script>
<script src="<?php echo e(asset('assets/admin/js/language.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/creativedesignbd/news2.creativedesign.com.bd/project/resources/views/admin/language/edit.blade.php ENDPATH**/ ?>